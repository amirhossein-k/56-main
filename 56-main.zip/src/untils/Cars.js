export const Cars = [
  {
    id: 1,
    image:
      "https://res.cloudinary.com/dijamrzud/image/upload/v1668963165/thumb_hbnxbw.jpg",
    name: "samand",
    catagory: "saipa",
    price: 230,
  },
  {
    id: 2,
    image:
      "https://res.cloudinary.com/dijamrzud/image/upload/v1668963162/thumb_1_zkrqty.jpg",
    name: "pgo",
    catagory: "saipa",
    price: 130,
  },
  {
    id: 3,
    image:
      "https://res.cloudinary.com/dijamrzud/image/upload/v1668963157/thumb_2_yk73fb.jpg",
    name: "peraid",
    catagory: "saipa",
    price: 200,
  },
  {
    id: 4,
    image:
      "https://res.cloudinary.com/dijamrzud/image/upload/v1668963157/thumb_2_yk73fb.jpg",
    name: "qiuk",
    catagory: "saipa",
    price: 400,
  },
  {
    id: 5,
    image:
      "https://res.cloudinary.com/dijamrzud/image/upload/v1668963156/thumb_3_wfnem1.jpg",
    name: "pgo",
    catagory: "irankhodro",
    price: 300,
  },
  {
    id: 6,
    image:
      "https://res.cloudinary.com/dijamrzud/image/upload/v1668962724/cars2_tgwa6d.jpg",
    name: "pgo",
    catagory: "irankhodro",
    price: 500,
  },
];
